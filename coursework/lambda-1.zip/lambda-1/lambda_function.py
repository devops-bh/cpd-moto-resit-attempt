import boto3
import json
sns_client = boto3.client("sns", region_name="us-east-1", endpoint_url="http://localhost:5000")
"""response = client.create_function(
        Code={'ZipFile': open('./process-image-lambda.zip', 'rb').read()},
        Description='Process image objects from Amazon S3.',
        FunctionName='process-image',
        #Handler='processimagefile.handler',
        Handler='lambda_function.lambda_handler',
        Publish=True,
        Runtime='python3.10',
        Role=role_arn
    )
"""
response = sns_client.create_topic(Name="s3-image-recieved")
response = sns_client.publish(
    TopicArn='arn:aws:sns:us-east-1:123456789012:s3-image-recieved',
    Message=json.dumps({
        "image_path": "image1.jpg", "bucket_name": "bucketname" 
    }),
    Subject='s3-image-received',
)


# ___ 

"""
Extract image file name (or path) & S3 bucket name from SNS notification
Call the AWS Rekognition detect_labels function 
Store the labels and their confidence score in a dictionary 
Call the AWS Rekognition detect_text function 
Store the labels and their confidence score in a dictionary 
Send the above data to an SQS queue 
"""

import boto3

def lambda_handler(event, context):
    rekognition_client = boto3.client("rekognition", region_name="us-east-1", endpoint_url="http://localhost:5000")
    sns_client = boto3.client("sns", region_name="us-east-1", endpoint_url="http://localhost:5000")

    # extract from SNS notification 
    response = sns_client.subscribe(
        TopicArn="arn:aws:sns:us-east-1:123456789012:s3-image-received",
        Protocol='lambda',
        Endpoint="arn:aws:lambda:us-east-1:123456789012:function:lambda_function_1",
        ReturnSubscriptionArn=True
    )
    print("\nSubscription Resp:\n", response)


    detect_text_response = rekognition_client.detect_text(Image={
        'S3Object': {
            'Bucket': "bucketname",
            'Name': 'image.jpg',
        }
    })
    print(detect_text_response)

    detect_labels_response = rekognition_client.detect_labels(
        Image={
            'S3Object': {
                'Bucket': 'bucketname',
                'Name': 'image.jpg',
            },
        },
    )
    print(detect_labels_response)
    # send to SQS queue 

lambda_handler(None, None)