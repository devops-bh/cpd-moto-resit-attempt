from datetime import datetime
from pathlib import Path
# not sure if need mock_aws
def lambda_handler(event, context): 
    """
    I am using Path.home as I was not sure if Moto/Localstack would create the file 
    in a directory of its own choice as opposed to the current directory when Moto/Localstack 
    was ran 
    https://stackoverflow.com/questions/4028904/what-is-a-cross-platform-way-to-get-the-home-directory#:~:text=If%20you%27re%20on%20Python%203.5%2B%20you%20can%20use%20pathlib.Path.home()%3A
    """
    print(str(Path.home())+"/lambdalastinvocation.txt")
    f = open(str(Path.home())+"/lambdalastinvocation.txt", "w")
    f.write(str(datetime.today().strftime('%Y-%m-%d'))+"\n"+datetime.now().strftime("%H:%M:%S"))
    f.close()
